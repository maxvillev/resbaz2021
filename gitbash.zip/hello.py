#
# hello.py - greetings around the world, add your own!
#
print("Hello")
print("Bula")
print("Bonjour!")

